ndfsac/zombit
======
_top-down zombie survival fun._

Zombit is an 8-bit retro style game that takes place in a dark office building. Fight off zombies and push through
floors of the building as you rack up a higher score to compete with the world. Chests and upgrades can be found around
the rooms. Upgrades will help you fight off more zombies with higher-powered weapons and nice stat boosters.

![zombit_preview](https://raw.github.com/ndfsac/zombit/master/screenshot/newscreen.png)

Currently the game is in _alpha_ preview with no set release date.  Not all of the features are done yet!  However since zombit is an open-source game, feel
free to download and play whenever you want! Don't forget to tell your friends.

Interested in helping with zombit? Send us some pull requests and you'll be considered in the future of zombit.
